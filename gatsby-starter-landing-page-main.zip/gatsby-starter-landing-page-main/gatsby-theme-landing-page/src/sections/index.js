export { default as Hero } from "./hero";
export { default as Features } from "./features";
export { default as Copy } from "./copy";
export { default as CallToAction } from "./call-to-action";
export { default as Benefits } from "./benefits";
export { default as Testimonial } from "./testimonial";
