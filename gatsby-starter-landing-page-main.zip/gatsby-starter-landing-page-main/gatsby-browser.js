import "@fontsource/inter/400.css";
import "@fontsource/inter/600.css";
